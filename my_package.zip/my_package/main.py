from my_package.greet import greet

name = input("Enter your name: ")
greeting = greet(name)
print(greeting)
