pip install wheel  # Install wheel package if not already installed
python setup.py bdist_wheel
