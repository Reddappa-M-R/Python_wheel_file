from my_package import greet

name = "Rocky"
greet(name)