#greet
def greet(name):
    return f"Hello, {name}!"

greet("Reddy")