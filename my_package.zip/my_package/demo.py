from my_package import greet

name = "Rocky"
print(greet(name))