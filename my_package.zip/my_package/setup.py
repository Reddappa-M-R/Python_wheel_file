# setup.py
from setuptools import setup, find_packages

setup(
    name='my_package',
    version='1.0.1',
    description='A simple package example',
    author='Reddy',
    author_email='reddy2018@gmail.com',
    packages=find_packages(),
)